---
name: 5. Documentation
about: I have something to improve or add to the docs
title: ''
labels: documentation
assignees: ''

---

**Describe your changes**
A clear and concise description of what you like to add or change.

**Location**
Where should these changes be made or the information published?
Wiki, README, ...

**Additional context**
Add any other context about your proposal.
