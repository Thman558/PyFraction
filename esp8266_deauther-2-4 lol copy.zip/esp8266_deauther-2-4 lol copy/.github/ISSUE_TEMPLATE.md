> Please search for existing (open and closed) issues first to avoid duplicates.  
Also have a look at the [Wiki](https://github.com/spacehuhntech/esp8266_deauther/wiki).  

```
PASTE YOUR ERROR/COMPILE LOGS HERE
```